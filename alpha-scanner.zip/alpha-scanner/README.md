# Crypto Alpha Signal Scanner & Backtester

A multi-source alpha research platform that computes z-score trading signals from 5 independent data sources, combines them into a composite signal, and backtests long/short strategies on BTC and ETH.

![Python](https://img.shields.io/badge/Python-3.10+-blue)
![Streamlit](https://img.shields.io/badge/Streamlit-Dashboard-red)

## Data Sources

| # | Source | Signal | Logic |
|---|--------|--------|-------|
| 1 | Binance Futures | Perpetual funding rate | Contrarian: extreme negative funding → buy |
| 2 | Alternative.me | Fear & Greed Index | Contrarian: extreme fear → buy |
| 3 | Binance Futures | Open interest changes | Contrarian: rapid OI spike without price → overleveraged |
| 4 | CoinGecko | BTC market cap (dominance proxy) | Rising dominance → risk-off signal |
| 5 | Price data | Fast/slow MA crossover | Momentum: trend-following |

All sources are free and require no API keys.

## How It Works

1. **Fetch** hourly OHLCV, 8-hourly funding rates, daily Fear & Greed, and OI from public APIs
2. **Compute** rolling z-scores for each source (normalised to mean 0, std 1)
3. **Combine** into a weighted composite signal (configurable weights via dashboard)
4. **Backtest** a long/short strategy with volatility targeting and transaction costs
5. **Analyse** signal decay across horizons, regime performance, and IS/OOS split

## Quick Start

```bash
# Clone
git clone https://github.com/yourusername/alpha-scanner.git
cd alpha-scanner

# Install
pip install -r requirements.txt

# Option A: Use sample data (instant demo)
python generate_sample_data.py

# Option B: Fetch real data from Binance + APIs
python src/data_fetcher.py

# Launch dashboard
streamlit run app.py
```

## Dashboard Features

- **Equity curve** with in-sample / out-of-sample split and drawdown
- **Individual signal plots** (funding, fear/greed, OI, dominance, momentum)
- **Composite signal** with configurable weights via sidebar sliders
- **Signal decay analysis** — forward returns by quintile at 1h to 168h horizons
- **Regime performance** — strategy returns split by low/medium/high volatility
- **Position distribution** histogram
- **Live parameter tuning** — entry threshold, vol target, cost bps, signal weights

## Project Structure

```
alpha-scanner/
├── app.py                    # Streamlit dashboard
├── generate_sample_data.py   # Synthetic data for demo
├── requirements.txt
├── data/                     # Parquet files (gitignored)
├── src/
│   ├── data_fetcher.py       # API calls: Binance, Alternative.me, CoinGecko
│   ├── signals.py            # Z-score signal computation + composite
│   └── backtester.py         # Position sizing, PnL engine, metrics
└── README.md
```

## Performance Metrics

The backtester reports: Sharpe ratio, Sortino ratio, Calmar ratio, max drawdown, win rate, average win/loss, total turnover, and number of position changes — all computed on both in-sample and out-of-sample periods.

## Configuration

All parameters are adjustable via the Streamlit sidebar:

| Parameter | Default | Description |
|-----------|---------|-------------|
| Entry threshold | 0.5 | Min composite z-score to open a position |
| Vol target | 20% | Annualised volatility target for position sizing |
| Cost (bps) | 5 | One-way transaction cost |
| Signal weights | Equal | Relative weight of each signal in composite |

## Author

Rajat Durge — MSc Emerging Digital Technologies, UCL
